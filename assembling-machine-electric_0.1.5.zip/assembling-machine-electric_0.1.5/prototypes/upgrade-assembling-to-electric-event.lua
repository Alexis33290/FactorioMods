
data:extend({
	{
		type = 'custom-input',
		name='upgradeAssemblingToElectricAssemblingMachine',
		linked_game_control = 'build',
		consuming = "none",
		key_sequence = "",
	}
})