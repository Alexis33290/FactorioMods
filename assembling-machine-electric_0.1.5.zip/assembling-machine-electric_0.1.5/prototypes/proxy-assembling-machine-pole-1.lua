

local globalShift=function(x,y)
	local addedX=0
	local addedY=40
	return util.by_pixel(x+addedX,y+addedY)
end

local wireShift=function(x,y)
	local addedX=0
	local addedY=40
	local addedXforWire=26
	local addedYforWire=20
	return util.by_pixel(x+addedX+addedXforWire, y+addedY+addedYforWire)
end

local wireShadowShift=function(x,y)
	local addedX=0
	local addedY=40
	local addedXforWire=26
	local addedYforWire=20
	local addedXforShadow=-25
	local addedYforShadow=-16
	return util.by_pixel(x+addedX+addedXforWire+addedXforShadow, y+addedY+addedYforWire+addedYforShadow)
end

local proxy_assembling_machine_pole = table.deepcopy(data.raw["electric-pole"]["small-electric-pole"])
local assembling_machine_std = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-1"])

proxy_assembling_machine_pole.name = "proxy-assembling-machine-pole-1"
proxy_assembling_machine_pole.minable = {minable = false, mining_time = 0}
proxy_assembling_machine_pole.flags = {"player-creation"}
proxy_assembling_machine_pole.collision_mask = assembling_machine_std.collision_mask
proxy_assembling_machine_pole.collision_box = assembling_machine_std.collision_box
proxy_assembling_machine_pole.pictures={
      layers =
      {
        {
          filename = "__base__/graphics/entity/small-electric-pole/small-electric-pole.png",
          priority = "extra-high",
          width = 36,
          height = 108,
          direction_count = 4,
          shift = globalShift(2, -42),
		  --shift = util.by_pixel(2,-2),
          hr_version =
          {
            filename = "__assembling-machine-electric__/graphics/entities/proxy-assembling-machine-pole-1.png",
            priority = "extra-high",
            width = 226,
            height = 214,
            direction_count = 4,
            shift = globalShift(1.5, -42.5),
			--shift = util.by_pixel(1.5,-2.5),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/small-electric-pole/small-electric-pole-shadow.png",
          priority = "extra-high",
          width = 130,
          height = 28,
          direction_count = 4,
          shift = globalShift(50, 2),
		  --shift = util.by_pixel(50,42),
          draw_as_shadow = true,
          hr_version =
          {
            filename = "__base__/graphics/entity/small-electric-pole/hr-small-electric-pole-shadow.png",
            priority = "extra-high",
            width = 256,
            height = 52,
            direction_count = 4,
            shift = globalShift(51, 3),
			--shift = util.by_pixel(51,43),
            draw_as_shadow = true,
            scale = 0.5
          }
        }
      }
    }

proxy_assembling_machine_pole.connection_points =
    {
      {
        shadow =
        {
          copper = wireShadowShift(98.5, 2.5-3),
          red = wireShadowShift(111.0, 4.5-3),
          green = wireShadowShift(85.5, 4.0-3)
		  --copper = util.by_pixel(123.5, 62.5),
		  --red = util.by_pixel(137,64.5),
		  --green = util.by_pixel(111.5,64)
        },
        wire =
        {
          copper = wireShift(0.0-11, -82.5),
          red = wireShift(13.0-11, -81.0),
          green = wireShift(-12.5-11, -81.0)
		  --copper = util.by_pixel(26, -22.5),
		  --red = util.by_pixel(39.5,-21),
		  --green = util.by_pixel(13.5,-21)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(99.5, 4.0-3),
          red = wireShadowShift(110.0, 9.0-3),
          green = wireShadowShift(92.5, -4.0-3)
		  --copper = util.by_pixel(125.5, 64),
		  --red = util.by_pixel(136.0,69),
		  --green = util.by_pixel(118.5,56)
        },
        wire =
        {
          copper = wireShift(1.5+8, -81.0-2),
          red = wireShift(12.0+8, -76.0-2),
          green = wireShift(-6.0+8, -89.5-2)
		  --copper = util.by_pixel(27.5, -21),
		  --red = util.by_pixel(38.0,-16),
		  --green = util.by_pixel(20,-29.5)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(100.5, 5.5-2),
          red = wireShadowShift(102.5, 14.5-2),
          green = wireShadowShift(103.5, -3.5-2)
		  --copper = util.by_pixel( ,  ),
		  --red = util.by_pixel( , ),
		  --green = util.by_pixel( , )
        },
        wire =
        {
          copper = wireShift(2.5+1, -79.5-1),
          red = wireShift(4.0+1, -71.0-1),
          green = wireShift(5.0+1, -89.5-1)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(98.5-2, -1.5-3),
          red = wireShadowShift(88.0-2, 3.5-3),
          green = wireShadowShift(106.0-2, -9.0-3)
        },
        wire =
        {
          copper = wireShift(0.5+2, -86.5-2),
          red = wireShift(-10.5+2, -81.5-2),
          green = wireShift(8.0+2, -93.5-2)
        }
      }
    }
    proxy_assembling_machine_pole.radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/electric-pole-radius-visualization.png",
      width = 12,
      height = 12,
      priority = "extra-high-no-scale"
    }
  


--data:extend{proxy_assembling_machine_pole}

data:extend(
{
	proxy_assembling_machine_pole, 
	{
		type = "recipe",
		name = "proxy-assembling-machine-pole-1",
		energy_required = 1,
		ingredients =
		{
			{"assembling-machine-1", 1},
			{"small-electric-pole", 1},
		},
		category = "crafting",
		result_count = 1,
		crafting_speed = 1,
		result = "proxy-assembling-machine-pole-1",
		enabled=false,
		--enabled=true,
	},
	{
		type = "item",
		name = "proxy-assembling-machine-pole-1",
		icon = "__assembling-machine-electric__/graphics/icons/assembling-machine-electic-1_icon.png",
		icon_size = 32,
		subgroup = "production-machine",
		order = "a[assembling-machine-1]-b[proxy-assembling-machine-1]",
		place_result = "proxy-assembling-machine-pole-1",
		stack_size = 50
	}
})



