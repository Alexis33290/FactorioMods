

--worked with those parameters once..
--	local addedX=-17
--	local addedY=23
--	local addedXforWire=28
--	local addedYforWire=20


local globalShift=function(x,y)
	local addedX=0
	local addedY=40
	return util.by_pixel(x+addedX, y+addedY)
end

local wireShift=function(x,y)
	local addedX=-0
	local addedY=40
	local addedXforWire=28
	local addedYforWire=20
	return util.by_pixel(x+addedX+addedXforWire, y+addedY+addedYforWire)
end

local wireShadowShift=function(x,y)
	local addedX=0
	local addedY=40
	local addedXforWire=26
	local addedYforWire=20
	local addedXforShadow=-20
	local addedYforShadow=-16
	return util.by_pixel(x+addedX+addedXforWire+addedXforShadow, y+addedY+addedYforWire+addedYforShadow)
end

local assembling_machine_pole = table.deepcopy(data.raw["electric-pole"]["small-electric-pole"])
assembling_machine_pole.name = "assembling-machine-pole"
assembling_machine_pole.minable = {minable = false, mining_time = 0}
assembling_machine_pole.flags = {"player-creation"} --"placeable-off-grid"
--assembling_machine_pole.placeable_position_visualization = nil
--assembling_machine_pole.collision_box = {{-0, -0}, {0, 0}}
assembling_machine_pole.collision_mask = {}
--assembling_machine_pole.drawing_box = {{-5, -5}, {5, 5}}--{{-0.5, -2.6}, {0.5, 0.5}}
assembling_machine_pole.selection_box = {{-0.5, -0.5}, {0.5, 0.5}}
assembling_machine_pole.pictures =
    {
      layers =
      {
        {
		  filename = "__assembling-machine-electric__/graphics/entities/assembling_machine_poles4directions.png",
            priority = "extra-high",
            width = 226,
            height = 214,
            direction_count = 4,
            shift = globalShift(1.5, -42.5),
			--shift = globalShift(0, 0),
            scale = 0.5,
          -- filename = "__assembling-machine-electric__/graphics/entities/hr-assembling_machine_pole.png",
          -- priority = "extra-high",
          -- width = 36,
          -- height = 108,
          -- direction_count = 4,
          -- shift = globalShift(2, -42),
		  shift = globalShift(0, 0),
          hr_version =
          {
            filename = "__assembling-machine-electric__/graphics/entities/assembling_machine_poles4directions.png",
            priority = "extra-high",
            width = 226,
            height = 214,
            direction_count = 4,
            shift = globalShift(1.5, -42.5),
			--shift = globalShift(0, 0),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/small-electric-pole/small-electric-pole-shadow.png",
          priority = "extra-high",
          width = 130,
          height = 28,
          direction_count = 4,
          shift = globalShift(50, 2),
          draw_as_shadow = true,
          hr_version =
          {
            filename = "__base__/graphics/entity/small-electric-pole/hr-small-electric-pole-shadow.png",
            priority = "extra-high",
            width = 256,
            height = 52,
            direction_count = 4,
            shift = globalShift(51, 3),
            draw_as_shadow = true,
            scale = 0.5
          }
        }
      }
    }
assembling_machine_pole.connection_points =
    {
      {
        shadow =
        {
          copper = wireShadowShift(98.5-12, 2.5-3),
          red = wireShadowShift(111.0-12, 4.5-3),
          green = wireShadowShift(85.5-12, 4.0-3)
        },
        wire =
        {
          copper = wireShift(0.0-13, -82.5),
          red = wireShift(13.0-13, -81.0),
          green = wireShift(-12.5-13, -81.0)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(99.5-5, 4.0-4),
          red = wireShadowShift(110.0-5, 9.0-4),
          green = wireShadowShift(92.5-5, -4.0-4)
        },
        wire =
        {
          copper = wireShift(1.5+5, -81.0-3),
          red = wireShift(12.0+5, -76.0-3),
          green = wireShift(-6.0+5, -89.5-3)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(100.5-5, 5.5-3),
          red = wireShadowShift(102.5-5, 14.5-3),
          green = wireShadowShift(103.5-5, -3.5-3)
        },
        wire =
        {
          copper = wireShift(2.5-1, -79.5),
          red = wireShift(4.0-1, -71.0),
          green = wireShift(5.0-1, -89.5)
        }
      },
      {
        shadow =
        {
          copper = wireShadowShift(98.5-5, -1.5-5),
          red = wireShadowShift(88.0-5, 3.5-5),
          green = wireShadowShift(106.0-5, -9.0-5)
        },
        wire =
        {
          copper = wireShift(0.5-1, -86.5-1),
          red = wireShift(-10.5-1, -81.5-1),
          green = wireShift(8.0-1, -93.5-1)
        }
      }
    }
    assembling_machine_pole.radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/electric-pole-radius-visualization.png",
      width = 12,
      height = 12,
      priority = "extra-high-no-scale"
    }
  

data:extend(
{
	assembling_machine_pole, 
})



