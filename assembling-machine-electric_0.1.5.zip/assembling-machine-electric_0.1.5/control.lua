require ("lib/util_ext") 


local function isAssemblingMachine(entityName)
	local result = false
	--local entityName=entity.name
	if entityName=='assembling-machine-1' or entityName == 'assembling-machine-2' or entityName == 'assembling-machine-3' then
		result=true
	end
	return result
end 

local function isSmallElectricPole(entityName)
	local result = false
	--local entityName=entity.name
	if entityName=='small-electric-pole' then
		result=true
	end
	return result
end 

local function isProxyAssemblingMachine(entityName)
	local result = false
	--local entityName=entity.name
	if entityName=='proxy-assembling-machine-pole-1' or entityName == 'proxy-assembling-machine-pole-2' or entityName == 'proxy-assembling-machine-pole-3' then
		result=true
	end
	return result
end 

local function isInGroup(entity)
	local result = false
	local position=entity.position
	local pos_hash = cantor(position.x,position.y)
	local entity_group = getGroup_entities(pos_hash)
	if entity_group==nil then
		result=false
	else
		result=true
	end
	return result
end

local function destroyAndPair(entityToDestroy, newMachine, newElectricPole)
	local position=entityToDestroy.position
	entityToDestroy.destroy()
	-----must remove pair of the destroyed entity ! ------------------------------------ TODO
	newMachine.minable = true
	newMachine.destructible = true
	newElectricPole.minable=false
	newElectricPole.destructible=false
	group_entities(cantor(position.x,position.y), {newMachine, newElectricPole})
	--game.players[1].insert({name='wooden-chest', count=1}) --------------------------- ATTENTION !!!!! TEST ONLY TO REMOVE for singlePlayer
end

local function payFromHandStack(player)
	local itemName=player.cursor_stack.name
	player.cursor_stack.count=player.cursor_stack.count-1
	if player.cursor_stack.valid_for_read==false then --when no more item in hand, get fresh stack.
		local additional_stack_from_inventory=player.get_inventory(defines.inventory.item_main).find_item_stack(itemName)
		if additional_stack_from_inventory~=nil then
			player.cursor_stack.transfer_stack(additional_stack_from_inventory)
		end
	end
end

local function refundItem(player, itemName, itemCount)
	if player.get_inventory(defines.inventory.item_main).can_insert({name=itemName,count=itemCount}) then
		player.insert({name=itemName, count=1})
	else
		-- manage inventory full => take what you can, put the rest on floor -------------------TODO
	end
end

local function refundStack(player,stack)
	if stack.valid_for_read and stack.count >0  then
		refundItem(player, stack.name, stack.count)
	end
end

local function insertStackInMachine(player, machine, stack)
	if stack.valid_for_read and stack.count >0  then
		if machine.can_insert(stack) then
			machine.insert(stack)
		else
			refundStack(player, stack)
		end
	end
end


local function On_Built(event)
	--test game.players[event.player_index].insert({name="steel-chest", count=1})
	local entity = event.created_entity
	local surface = entity.surface
	local position = entity.position
	local force = entity.force
	
	if entity.valid and (entity.name == "proxy-assembling-machine-pole-1" or entity.name == "proxy-assembling-machine-pole-2" or entity.name == "proxy-assembling-machine-pole-3") then   
		local create_pole = surface.create_entity({name = "assembling-machine-pole" , position = position, force = force})
		local create_assembling_machine_electric
		if	entity.name == "proxy-assembling-machine-pole-1" then
			create_assembling_machine_electric = surface.create_entity({name = "assembling-machine-1", position = position, force = force,raise_built=true})
		end
		if	entity.name == "proxy-assembling-machine-pole-2" then
			create_assembling_machine_electric = surface.create_entity({name = "assembling-machine-2", position = position, force = force,raise_built=true})
		end
		if	entity.name == "proxy-assembling-machine-pole-3" then
			create_assembling_machine_electric = surface.create_entity({name = "assembling-machine-3", position = position, force = force,raise_built=true})
		end
		entity.destroy()
		create_pole.minable = false
		create_pole.destructible = false
		create_assembling_machine_electric.minable = true
		create_assembling_machine_electric.destructible = true
		group_entities(cantor(position.x,position.y), {create_assembling_machine_electric, create_pole})	  
	end
end

local function On_Die(event)
	local entity = event.entity	
	local surface = entity.surface
	local position = entity.position
	local force = entity.force
	--- assembling-machine-electric has been removed
   	if entity.valid and (entity.name == "assembling-machine-1" or entity.name == "assembling-machine-2" or entity.name == "assembling-machine-3") then
		local pos_hash = cantor(position.x,position.y)
        local entity_group = getGroup_entities(pos_hash)
        if entity_group then
            for ix, vx in ipairs(entity_group) do
                    vx.destroy()
            end
        end
        ungroup_entities(pos_hash)
	end
end
	
local function On_Remove(event)
	local entity = event.entity	
	local surface = entity.surface
	local position = entity.position
	local force = entity.force
	--- assembling-machine-electric has been removed
   	if entity.valid and (entity.name == "assembling-machine-1" or entity.name == "assembling-machine-2" or entity.name == "assembling-machine-3") then
		local pos_hash = cantor(position.x,position.y)
        local entity_group = getGroup_entities(pos_hash)
        if entity_group then
            for ix, vx in ipairs(entity_group) do
                    vx.destroy()
            end
			--if(event.name~="on_entity_died") then ----Trouver comment on dit ça permettrait de supprimer la function On_Die.
				local p = game.players[event.player_index]
				p.get_inventory(defines.inventory.item_main).insert({name='small-electric-pole',count=1})--in addition to the standard assembling-machine-1
				--add the small-electric-pole to the inventory
			--end
        end
        ungroup_entities(pos_hash)
	end
end

local function TransferAllContentFromAssemblyToDeleteToNewlyCreatedAssemblingMachine(oldMachine,newMachine,player)	
	newMachine.copy_settings(oldMachine)
	local oldMachineCurrentInputInventory=oldMachine.get_inventory(defines.inventory.assembling_machine_input)
	local oldMachineCurrentOutputInventory=oldMachine.get_inventory(defines.inventory.assembling_machine_output)
	local oldMachineCurrentModules=oldMachine.get_inventory(defines.inventory.assembling_machine_modules)

	
	local nbrInputStack=#oldMachineCurrentInputInventory
	for i=1,nbrInputStack,1 do
		insertStackInMachine(player, newMachine, oldMachineCurrentInputInventory[i])
	end					
	--get oldMachine created content (output) in player inventory. 
	local nbrOutputStack=#oldMachineCurrentOutputInventory
	for i=1,nbrOutputStack,1 do
		refundStack(player,oldMachineCurrentOutputInventory[i])
	end
	--get modules from oldMachine and put them in newMachine
	local nbrModule=#oldMachineCurrentModules
	for i=1,nbrModule,1 do
		insertStackInMachine(player, newMachine, oldMachineCurrentModules[i])
	end	
end


local function UpdateStdAssemblyToElectric(event) 
	local player = game.players[event.player_index]
	if player.selected and player.cursor_stack.valid_for_read then
		local entity = player.selected --entity to replace
		local entityName=entity.name--name of the entity to replace
		if isAssemblingMachine(entityName) then
			local newEntityIsAssemblingMachine = isAssemblingMachine(player.cursor_stack.name)
			local newEntityIsSmallElectricPole = isSmallElectricPole(player.cursor_stack.name)
			local newEntityIsProxyAssemblingMachine = isProxyAssemblingMachine(player.cursor_stack.name)		
			local selectedIsInGroup = isInGroup(entity)
					
			if true==false then --test only
			-----TESTS
				if selectedIsAssemblingMachine then game.players[event.player_index].insert({name='wooden-chest', count=1}) end
				if selectedIsProxyAssemblingMachine then game.players[event.player_index].insert({name='wooden-chest', count=50}) end
				if newEntityIsAssemblingMachine then game.players[event.player_index].insert({name='iron-chest', count=1}) end
				if newEntityIsProxyAssemblingMachine then game.players[event.player_index].insert({name='steel-chest', count=1}) end
				if newEntityIsSmallElectricPole then game.players[event.player_index].insert({name='steel-plate', count=1}) end
				if selectedIsInGroup==false then game.players[event.player_index].insert({name='iron-chest', count=50}) end
				if selectedIsInGroup==true then game.players[event.player_index].insert({name='steel-chest', count=50}) end
			-----END TESTS
			end
			
			local position=entity.position
			local pos_hash = cantor(position.x,position.y)
			local entity_group = getGroup_entities(pos_hash)
			local surface=entity.surface
			local force=entity.force

			if newEntityIsSmallElectricPole then --upgrading an assembling-machine to add an electric pole:
				if selectedIsInGroup==false then
					local assembling_machine_pole = surface.create_entity({name = "assembling-machine-pole", position = position, force = force,})
					local assembling_machine_electric= surface.create_entity({name = entityName, position = position, force = force,raise_built=true})
					TransferAllContentFromAssemblyToDeleteToNewlyCreatedAssemblingMachine(entity,assembling_machine_electric,player)	
					destroyAndPair(entity, assembling_machine_electric, assembling_machine_pole)
					payFromHandStack(player)
				else 
					--nothing to do because there is already an electric pole on this assembling machine: exit function
					do return end 
				end
			 elseif newEntityIsAssemblingMachine or newEntityIsProxyAssemblingMachine then
				--updating an assembling machine with another one, or with a proxy
				if selectedIsInGroup==true then
					--local cusor_stack_name= player.cursor_stack.name --get a stack of classical machine from inventory if placing proxy and run out in hand  -------------------TODO OPTIONAL
					local newMachineName = player.cursor_stack.name
					-- if replacement of a paired machine with a proxy, creation of the corresponding standard machine + player get electric-pole back
					if newEntityIsProxyAssemblingMachine then
						refundItem(player,'small-electric-pole',1)
						if newMachineName == 'proxy-assembling-machine-pole-1' then newMachineName='assembling-machine-1'
						elseif newMachineName == 'proxy-assembling-machine-pole-2' then newMachineName='assembling-machine-2'
						elseif newMachineName == 'proxy-assembling-machine-pole-3' then newMachineName='assembling-machine-3'
						end	
					end

					local assembling_machine_pole = surface.create_entity({name = "assembling-machine-pole", position = position, force = force})
					--machine must be created AFTER electric-pole to have the electric pole image on top of the machine
					local assembling_machine_electric= surface.create_entity({name = newMachineName, position = position, force = force,raise_built=true})
					TransferAllContentFromAssemblyToDeleteToNewlyCreatedAssemblingMachine(entity,assembling_machine_electric,player)		
					destroyAndPair(entity, assembling_machine_electric, assembling_machine_pole)
					payFromHandStack(player)
					refundItem(player,entityName,1) --get back the initial assembling machine
				else --selectedIsInGroup==false
					if newEntityIsAssemblingMachine then
						--this is a classic assembling machine upgrade, not an electric machine: nothing to manage
						do return end
					
					elseif newEntityIsProxyAssemblingMachine then --placing a proxy assembling machine on top of a regular assembling machine
						local newMachineName = player.cursor_stack.name
						-- if replacement of a paired machine with a proxy, creation of the corresponding standard machine + player get electric-pole back

						if newMachineName == 'proxy-assembling-machine-pole-1' then newMachineName='assembling-machine-1'
						elseif newMachineName == 'proxy-assembling-machine-pole-2' then newMachineName='assembling-machine-2'
						elseif newMachineName == 'proxy-assembling-machine-pole-3' then newMachineName='assembling-machine-3'
						end	
						local assembling_machine_pole = surface.create_entity({name = "assembling-machine-pole", position = position, force = force})
						--machine must be created AFTER electric-pole to have the electric pole image on top of the machine
						local assembling_machine_electric= surface.create_entity({name = newMachineName, position = position, force = force,raise_built=true})
						TransferAllContentFromAssemblyToDeleteToNewlyCreatedAssemblingMachine(entity,assembling_machine_electric,player)		
						destroyAndPair(entity, assembling_machine_electric, assembling_machine_pole)
						payFromHandStack(player)
						refundItem(player,entityName,1) --get back the initial assembling machine

					end
				end
				
			end
		end
	end
end


script.on_event(defines.events.on_built_entity, On_Built)
script.on_event(defines.events.on_robot_built_entity, On_Built)
script.on_event(defines.events.script_raised_built, On_Built)
script.on_event(defines.events.script_raised_revive, On_Built)
script.on_event(defines.events.on_entity_cloned, On_Built)

script.on_event(defines.events.on_player_mined_entity, On_Remove)
script.on_event(defines.events.on_robot_mined_entity, On_Remove)
script.on_event(defines.events.script_raised_destroy, On_Remove)

script.on_event(defines.events.on_entity_died, On_Die)

script.on_event("upgradeAssemblingToElectricAssemblingMachine",UpdateStdAssemblyToElectric)

script.on_event(defines.events.script_raised_built,On_assembling_machine_rise)