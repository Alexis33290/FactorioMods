
if data.raw.technology["automation"] and data.raw.recipe["proxy-assembling-machine-pole-1"] then
  table.insert(data.raw["technology"]["automation"].effects, {type = "unlock-recipe", recipe = "proxy-assembling-machine-pole-1",})	
end 
if data.raw.technology["automation-2"] and data.raw.recipe["proxy-assembling-machine-pole-2"] then
  table.insert(data.raw["technology"]["automation-2"].effects, {type = "unlock-recipe", recipe = "proxy-assembling-machine-pole-2",})	
end 
if data.raw.technology["automation-3"] and data.raw.recipe["proxy-assembling-machine-pole-3"] then
  table.insert(data.raw["technology"]["automation-3"].effects, {type = "unlock-recipe", recipe = "proxy-assembling-machine-pole-3",})	
end 

